## Phase II: Data Curation, Exploratory Analysis, and Plotting

### Team：T4.15
### Names：Samuel Zheng，Trung Nguyen, Andres Matton-Conover, Fan Du
### DS3000

## Project Goal:
Finding good professors is key to a great college experience, especially at a big school like Northeastern. We’re exploring which colleges have the best-rated professors using Rate My Professor data to help students choose classes and show the university where teaching quality excels or needs work.

## Objectives:
  Our goal is to look at professor ratings in different colleges and departments at Northeastern University using data from the Rate My Professor website. By checking out the average ratings and how they’re spread out, we want to give students helpful information to make better choices when picking their classes. Plus, this analysis can give the university a clear picture of teaching quality across its colleges, showing where things are going well and where there might be room for improvement

## References:
  Articles
  Pérez-Rivero, C. A., de Obesso, M. de la M., & Núñez-Canal, M. (2022). Digital competence among university professors: analysis of the impact of the COVID crisis. Economic Research-Ekonomska Istraživanja, 36(3). https://doi.org/10.1080/1331677X.2022.2155859
  Murray D, Boothby C, Zhao H, Minik V, Bérubé N, Larivière V, Sugimoto CR. Exploring the personal and professional factors associated with student evaluations of tenure-track faculty. PLoS One. 2020 Jun 3;15(6):e0233515. doi: 10.1371/journal.pone.0233515. PMID: 32492028; PMCID: PMC7269236. https://pubmed.ncbi.nlm.nih.gov/32492028/

## Data Introduction:
The data are 3490 rows x 13 columns (i.e. 45370 individual cells)
Each row represents a specific professor at Northeastern University
The columns are as such: First Name, Middle Name, Last Name, ID, Department, Institution Name, Institution ID, Number of Ratings, Average Rating (Out of 5), Would Take Again (Percent), Level of Difficulty (Out of 5), Popular Tags, Reviews

## Data Collection:
### Data Source
  Website: https://www.ratemyprofessors.com/
  Data to be Scraped: Each individual Northeastern professor’s statistical and review data
### 3.	Data Scraping Process
  Libraries: Pandas, BeautifulSoup, Requests
  ratemyprof-api (Created by Nathaniel Louis Tisuela) used for finding professors tags and reviews
  1.	Use the API to collect Northeastern University professor names, tags, and some other miscellaneous information.
  2.	Filter the created data frame to just keep the professor names, tags, and department information. 
  3.	Remove two specific professors who don’t exist on the website
  4.	Use the tags to find the specific URL for each Northeastern professor.
  5.	On each URL, scrape necessary statistical data for the professor and call the API to get the reviews. 
  6.	Concatenate everything into one synthesized data frame.
## Data Cleaning and Organization 
  1. Remove the review column as there was only mashed-up information about comments and ratings which were already presented in the other
     columns.
  2. Remove rows that had no ratings for the columns: 'Average Rating (Out of 5)', 'Would Take Again (Percent)',
     'Level of Difficulty (Out of 5)'
## Visualization (Andres take care of this)
## Division of works

  














